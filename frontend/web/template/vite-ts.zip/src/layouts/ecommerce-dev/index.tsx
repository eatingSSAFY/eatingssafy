import Header from './header-date';
import HeaderSecond from './header-floor';

// ----------------------------------------------------------------------

type Props = {
  children: React.ReactNode;
};

export default function EcommerceLayout({ children }: Props) {
  return (
    <>
      <Header />
      <HeaderSecond />

      {children}
    </>
  );
}
