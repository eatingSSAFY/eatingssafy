// ----------------------------------------------------------------------

export const GOOGLE_MAP_API = import.meta.env.VITE_MAP_API;
