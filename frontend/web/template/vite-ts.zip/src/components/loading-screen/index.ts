export { default as SplashScreen } from './splash-screen';
