export { default } from './player';

export { default as PlayerDialog } from './player-dialog';
