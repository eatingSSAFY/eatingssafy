export { default as LocalizationProvider } from './localization-provider';
